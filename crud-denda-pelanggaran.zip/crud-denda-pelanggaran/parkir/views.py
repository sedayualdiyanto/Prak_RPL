from django.shortcuts import render, redirect
from .models import Kendaraan, Denda, Pembayaran, Petugas, LokasiParkir
from datetime import date

def index(request):
    return render(request, 'index.html')
    

# ===================== KENDARAAN =====================
def kendaraan_list(request):
    data = Kendaraan.objects.all()
    return render(request, 'kendaraan_list.html', {'kendaraan': data})

def kendaraan_tambah(request):
    if request.method == 'POST':
        Kendaraan.objects.create(
            plat=request.POST['plat'],
            pemilik=request.POST['pemilik'],
            jenis=request.POST['jenis']
        )
        return redirect('kendaraan_list')
    return render(request, 'kendaraan_form.html')

def kendaraan_edit(request, id):
    item = Kendaraan.objects.get(id=id)
    if request.method == 'POST':
        item.plat = request.POST['plat']
        item.pemilik = request.POST['pemilik']
        item.jenis = request.POST['jenis']
        item.save()
        return redirect('kendaraan_list')
    return render(request, 'kendaraan_form.html', {'k': item})

def kendaraan_hapus(request, id):
    Kendaraan.objects.get(id=id).delete()
    return redirect('kendaraan_list')

# ===================== DENDA =====================
def denda_list(request):
    denda = Denda.objects.all()

    # Ambil nilai tanggal dari GET
    t_awal = request.GET.get('t_awal')
    t_akhir = request.GET.get('t_akhir')

    # Jika dua tanggal diisi → filter
    if t_awal and t_akhir:
        denda = denda.filter(tanggal__range=[t_awal, t_akhir])

    return render(request, 'denda_list.html', {
        'denda': denda,
        't_awal': t_awal,
        't_akhir': t_akhir
    })


def denda_tambah(request):
    kendaraan = Kendaraan.objects.all()

    if request.method == 'POST':
        Denda.objects.create(
            kendaraan_id=request.POST['kendaraan'],
            pelanggaran=request.POST['pelanggaran'],
            jumlah_denda=request.POST['jumlah_denda'],
            tanggal=date.today()
        )
        return redirect('denda_list')

    return render(request, 'denda_form.html', {
        'kendaraan': kendaraan,
        'd': None
    })

def denda_edit(request, id):
    item = Denda.objects.get(id=id)
    kendaraan = Kendaraan.objects.all()

    if request.method == 'POST':
        item.kendaraan_id = request.POST['kendaraan']
        item.pelanggaran = request.POST['pelanggaran']
        item.jumlah_denda = request.POST['jumlah_denda']
        item.save()
        return redirect('denda_list')

    return render(request, 'denda_form.html', {
        'd': item,
        'kendaraan': kendaraan
    })

def denda_hapus(request, id):
    Denda.objects.get(id=id).delete()
    return redirect('denda_list')
def pembayaran_list(request):
  data = Pembayaran.objects.all()
  return render(request, 'pembayaran_list.html', {'pembayaran': data})

# ===================== PEMBAYARAN =====================
def pembayaran_tambah(request):
  denda = Denda.objects.all()

  if request.method == 'POST':
      Pembayaran.objects.create(
          denda_id=request.POST['denda'],
          tanggal_bayar=request.POST['tanggal_bayar'],
          jumlah_bayar=request.POST['jumlah_bayar'],
      )
      return redirect('pembayaran_list')

  return render(request, 'pembayaran_form.html', {'denda': denda})

def pembayaran_edit(request, id):
    item = Pembayaran.objects.get(id=id)
    denda_list = Denda.objects.all()

    if request.method == "POST":
        denda_obj = Denda.objects.get(id=request.POST['denda'])

        item.denda_id = denda_obj.id
        item.tanggal_bayar = request.POST['tanggal_bayar']
        item.jumlah_bayar = denda_obj.jumlah_denda   # <-- AUTO FOLLOW DENDA
        item.save()
        return redirect('pembayaran_list')

    return render(request, "pembayaran_form.html", {
        "p": item,
        "denda": denda_list
    })



def pembayaran_hapus(request, id):
  Pembayaran.objects.get(id=id).delete()
  return redirect('pembayaran_list')

# ===================== PETUGAS =====================
def petugas_list(request):
    data = Petugas.objects.all()
    return render(request, 'petugas_list.html', {'petugas': data})

def petugas_tambah(request):
    if request.method == 'POST':
        Petugas.objects.create(
            nama=request.POST['nama'],
            nip=request.POST['nip'],
            jabatan=request.POST['jabatan']
        )
        return redirect('petugas_list')
    return render(request, 'petugas_form.html')

def petugas_edit(request, id):
    item = Petugas.objects.get(id=id)
    if request.method == 'POST':
        item.nama = request.POST['nama']
        item.nip = request.POST['nip']
        item.jabatan = request.POST['jabatan']
        item.save()
        return redirect('petugas_list')
    return render(request, 'petugas_form.html', {'p': item})

def petugas_hapus(request, id):
    Petugas.objects.get(id=id).delete()
    return redirect('petugas_list')

# ===================== LOKASI PARKIR =====================
def lokasi_list(request):
    data = LokasiParkir.objects.all()
    return render(request, 'lokasi_list.html', {'lokasi': data})

def lokasi_tambah(request):
    if request.method == 'POST':
        LokasiParkir.objects.create(
            nama=request.POST['nama'],
            alamat=request.POST['alamat'],
            kapasitas=request.POST['kapasitas']
        )
        return redirect('lokasi_list')
    return render(request, 'lokasi_form.html')

def lokasi_edit(request, id):
    item = LokasiParkir.objects.get(id=id)
    if request.method == 'POST':
        item.nama = request.POST['nama']
        item.alamat = request.POST['alamat']
        item.kapasitas = request.POST['kapasitas']
        item.save()
        return redirect('lokasi_list')
    return render(request, 'lokasi_form.html', {'l': item})

def lokasi_hapus(request, id):
    LokasiParkir.objects.get(id=id).delete()
    return redirect('lokasi_list')


