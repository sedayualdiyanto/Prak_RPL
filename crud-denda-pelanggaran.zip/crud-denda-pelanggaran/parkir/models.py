from django.db import models


class Kendaraan(models.Model):
    plat = models.CharField(max_length=20)
    pemilik = models.CharField(max_length=100)
    jenis = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.plat} - {self.pemilik}"


class Denda(models.Model):
    kendaraan = models.ForeignKey(Kendaraan, on_delete=models.CASCADE)
    pelanggaran = models.CharField(max_length=200)
    jumlah_denda = models.IntegerField()
    tanggal = models.DateField()

    def __str__(self):
        return f"{self.kendaraan} - {self.pelanggaran}"

class Pembayaran(models.Model):
  denda = models.ForeignKey(Denda, on_delete=models.CASCADE)
  tanggal_bayar = models.DateField()
  jumlah_bayar = models.IntegerField()

def __str__(self):
        return f"Pembayaran {self.jumlah_bayar} untuk {self.denda}"

class Petugas(models.Model):
    nama = models.CharField(max_length=100)
    nip = models.CharField(max_length=20)
    jabatan = models.CharField(max_length=50)
    
def __str__(self):
        return self.nama

class LokasiParkir(models.Model):
    nama = models.CharField(max_length=100)
    alamat = models.TextField()
    kapasitas = models.IntegerField()

    def __str__(self):
        return self.nama