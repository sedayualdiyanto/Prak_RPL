from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),

    # kendaraan
    path('kendaraan/', views.kendaraan_list, name='kendaraan_list'),
    path('kendaraan/tambah/', views.kendaraan_tambah, name='kendaraan_tambah'),
    path('kendaraan/edit/<int:id>/', views.kendaraan_edit, name='kendaraan_edit'),
    path('kendaraan/hapus/<int:id>/', views.kendaraan_hapus, name='kendaraan_hapus'),

    # denda
    path('denda/', views.denda_list, name='denda_list'),
    path('denda/tambah/', views.denda_tambah, name='denda_tambah'),
    path('denda/edit/<int:id>/', views.denda_edit, name='denda_edit'),
    path('denda/hapus/<int:id>/', views.denda_hapus, name='denda_hapus'),

    # pembayaran
    path('pembayaran/', views.pembayaran_list, name='pembayaran_list'),
    path('pembayaran/tambah/', views.pembayaran_tambah, name='pembayaran_tambah'),
    path('pembayaran/edit/<int:id>/', views.pembayaran_edit, name='pembayaran_edit'),
    path('pembayaran/hapus/<int:id>/', views.pembayaran_hapus, name='pembayaran_hapus'),
    
    # petugas
    path('petugas/', views.petugas_list, name='petugas_list'),
    path('petugas/tambah/', views.petugas_tambah, name='petugas_tambah'),
    path('petugas/edit/<int:id>/', views.petugas_edit, name='petugas_edit'),
    path('petugas/hapus/<int:id>/', views.petugas_hapus, name='petugas_hapus'),

    # lokasi parkir
    path('lokasi/', views.lokasi_list, name='lokasi_list'),
    path('lokasi/tambah/', views.lokasi_tambah, name='lokasi_tambah'),
    path('lokasi/edit/<int:id>/', views.lokasi_edit, name='lokasi_edit'),
    path('lokasi/hapus/<int:id>/', views.lokasi_hapus, name='lokasi_hapus'),
]
